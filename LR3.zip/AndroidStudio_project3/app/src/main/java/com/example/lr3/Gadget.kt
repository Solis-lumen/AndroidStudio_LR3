package com.example.lr3

data class Gadget(val name: String, val price: Double, val category: String, val inStock: Boolean)