package com.example.lr3

data class Student(val name: String, val unversity: String, var age: Int, var group: Int)