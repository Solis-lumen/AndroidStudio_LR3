package com.example.lr3

class Book constructor(var name: String, var author: String, var genre: String, var numberOfPages: Int)
{
    constructor(name: String) : this(name, "William Shakespeare", "poetry", 345) {}
    constructor(name: String, author: String) : this(name, author, "poetry", 123) {}
}