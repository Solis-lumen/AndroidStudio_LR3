package com.example.lr3

import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private var counter1: Int = 0
    private var counter2: Int = 0

    // перевизначена ф-я активності
    override fun onStart()
    {
        super.onStart()
        Toast.makeText(applicationContext, "Greeting from an overridden function 'onStart'!", Toast.LENGTH_LONG).show()
    }

    // ф-ї, що повертають різні типи значень
    fun getString() : String
    {
        return "Some text"
    }

    fun getInt() : Int
    {
        return 1234
    }

    fun getFloat() : Float
    {
        return 2.68f
    }

    fun getChar() : Char
    {
        return 'A'
    }

    fun getList(): List<String> {
        return listOf("Item 1", "Item 2", "Item 3")
    }

    fun onButtonClick1 (view: View)
    {
        val textView: TextView = findViewById(R.id.TextViewForResults) as TextView
        // використання циклу when з case
        when (counter1)
        {
            0 -> textView.text = getString()
            1 -> textView.text = getInt().toString()
            2 -> textView.text = getFloat().toString()
            3 -> textView.text = getChar().toString()
            4 -> textView.text = getList().toString()
        }

        if (counter1 >= 4)
            counter1 = 0
        else
            counter1++
    }

    fun onButtonClick2 (view: View)
    {
        val plantsArray = resources.getStringArray(R.array.plants)
        Toast.makeText(applicationContext, plantsArray[counter2], Toast.LENGTH_SHORT).show()
        if (counter2 >= plantsArray.size-1)
            counter2 = 0
        else
            counter2++
    }

    fun onButtonClick3 (view: View)
    {
        val student1 = Student("James", "BSNU", 20, 423)
        val student2 = Student("Ann", "BSNU", 19, 357)
        Toast.makeText(applicationContext, student1.toString(), Toast.LENGTH_SHORT).show()
        if (!student1.equals(student2))     // student1 != student2
        {
            Toast.makeText(applicationContext, "!student1.equals(student2)", Toast.LENGTH_SHORT).show()
        }

        val gadget = Gadget("Samsung S23", 500.3, "phone", true)
        val newGadget = gadget.copy(price = 800.0)
        Toast.makeText(applicationContext, newGadget.toString(), Toast.LENGTH_SHORT).show()
    }
}
