package com.example.lr3

class Vehicle constructor (val name: String, var price: Double)
{
    fun showName() = println(name)
    fun showPrice() = println(price)
}